<!--<template>-->
<!--  <div class="dashboard-container">-->
<!--    <component :is="currentDashboard" />-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--import adminDashboard from './admin'-->
<!--import coordinatorDashboard from './coordinator'-->
<!--import studentDashboard from './student'-->
<!--import tutorDashboard from './tutor'-->
<!--import clientDashboard from './client'-->

<!--export default {-->
<!--  name: 'Dashboard',-->
<!--  components: {-->
<!--    adminDashboard,-->
<!--    coordinatorDashboard,-->
<!--    studentDashboard,-->
<!--    tutorDashboard,-->
<!--    clientDashboard-->
<!--  },-->
<!--  data() {-->
<!--    return {-->
<!--      currentDashboard: null-->
<!--    }-->
<!--  },-->
<!--  created() {-->
<!--    const userRole = localStorage.getItem('userRole')-->
<!--    switch (userRole) {-->
<!--      case 'admin':-->
<!--        this.currentDashboard = 'adminDashboard'-->
<!--        break-->
<!--      case 'coordinator':-->
<!--        this.currentDashboard = 'coordinatorDashboard'-->
<!--        break-->
<!--      case 'student':-->
<!--        this.currentDashboard = 'studentDashboard'-->
<!--        break-->
<!--      case 'tutor':-->
<!--        this.currentDashboard = 'tutorDashboard'-->
<!--        break-->
<!--      case 'client':-->
<!--        this.currentDashboard = 'clientDashboard'-->
<!--        break-->
<!--      default:-->
<!--        this.currentDashboard = 'studentDashboard' // 默认显示学生的dashboard-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->

<!--<style scoped>-->
<!--.dashboard-container {-->
<!--  padding: 20px;-->
<!--}-->
<!--</style>-->



<template>
  <div class="dashboard-container">
    <component :is="currentRole" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import adminDashboard from './admin'
import editorDashboard from './editor'

export default {
  name: 'Dashboard',
  components: { adminDashboard, editorDashboard },
  data() {
    return {
      currentRole: 'adminDashboard'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  created() {
    if (!this.roles.includes('admin')) {
      this.currentRole = 'editorDashboard'
    }
  }
}
</script>
